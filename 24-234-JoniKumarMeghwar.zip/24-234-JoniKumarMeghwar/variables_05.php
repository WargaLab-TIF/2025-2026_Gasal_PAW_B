<?php
$name = "jai";
$age = 21;
$height = 1.68;
$isStudent = true;

echo "Name: $name, Age: $age, Height: $height, Is Student: $isStudent";
?>
