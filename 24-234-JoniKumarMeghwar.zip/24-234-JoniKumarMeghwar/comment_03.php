<?php
// This is a single-line comment
# This is also a single-line comment
/*
    This is a multi-line comment
*/


// echo "Hello World";
# echo "Hello World";


/*
$a = 10;
$b = 20;
echo $a + $b ; 
*/

echo "Comments are ignored by PHP";



?>
