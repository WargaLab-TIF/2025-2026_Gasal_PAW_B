<?php
$str = "Hello World";
echo "Length: " . strlen($str) . "<br>";
echo "Word Count: " . str_word_count($str) . "<br>";
echo "Reversed: " . strrev($str) . "<br>";
echo "Position of 'World': " . strpos($str, "World") . "<br>";
echo "Replace: " . str_replace("World", "PHP", $str);
?>
