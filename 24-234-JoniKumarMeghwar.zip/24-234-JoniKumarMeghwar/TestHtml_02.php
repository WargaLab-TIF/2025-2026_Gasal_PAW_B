<!DOCTYPE html>
<html>
<body>
    <h1><?php echo "This is PHP inside HTML"; ?></h1>
</body>
</html>
