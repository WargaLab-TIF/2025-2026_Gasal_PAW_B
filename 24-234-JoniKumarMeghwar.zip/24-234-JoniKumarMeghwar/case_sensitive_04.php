<?php
$color = "Red";
// echo $Color; // Error: undefined variable
echo $color; // Correct

$Color = "Blue";
echo $Color;

$COLar = "Green";
echo $COLar; 

?>
