<?php
$a = 10;
$b = 3;
echo "Sum: " . ($a + $b);
echo "<br>Product: " . ($a * $b);
?>
