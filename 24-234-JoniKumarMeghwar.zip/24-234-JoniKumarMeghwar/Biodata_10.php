<?php
$fullName = "Jai kumar";
$studentID = "123456789";
$class = "TI-3B";
$program = "Information Technology";
$address = "UTM";
$hobby = "Traveling";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Biodata</title>
    <style>
        table {
            border-collapse: collapse;
            width: 50%;
            
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
        }

        .tablehr{
            background-color: skyblue;
        }
    </style>
</head>
<body>
    <h2>Student Biodata</h2>
    <table>
        <tr class="tablehr">
            <th>Field</th>
            <th>Value</th>
        </tr>
        <tr><td>Full Name</td><td><?php echo $fullName; ?></td></tr>
        <tr><td>Student ID (NIM)</td><td><?php echo $studentID; ?></td></tr>
        <tr><td>Class</td><td><?php echo $class; ?></td></tr>
        <tr><td>Study Program</td><td><?php echo $program; ?></td></tr>
        <tr><td>Address</td><td><?php echo $address; ?></td></tr>
        <tr><td>Hobby</td><td><?php echo $hobby; ?></td></tr>
    </table>
</body>
</html>
