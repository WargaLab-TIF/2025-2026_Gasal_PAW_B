<?php 

function CheckFunc(){
 
    echo "Function Without Argument <br> ";

}
CheckFunc();

function withOneArg($name){
    echo "My name is {$name} <br>";

}

withOneArg("Jai kumar");


function add($a, $b) {
    return $a + $b;
}
echo "Sum: " . add(2, 3);

echo "<br>";

function greet($name = "Guest") {
    echo "Welcome, $name!";
}
greet();




?>